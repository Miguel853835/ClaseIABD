/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ies.ataulfo.json_a_csv;

import java.io.FileReader;
import java.io.FileWriter;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.IOException;

/**
 *
 * @author david
 */
public class Json_a_csv {

    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: java JSONtoCSVConverter <inputJSONFile> <outputCSVFile>");
            return;
        }

        String inputFilePath = args[0];
        String outputFilePath = args[1];

        JSONParser parser = new JSONParser();

        try (FileReader reader = new FileReader(inputFilePath);
             FileWriter writer = new FileWriter(outputFilePath)) {

            // Parse the JSON file
            //System.out.println("El archivo JSON: " + reader);
            Object obj = parser.parse(reader);
            //System.out.println("El  OBJETO JSON: " + obj);
            JSONObject jsonObject = (JSONObject) obj;
            JSONArray employees = (JSONArray) jsonObject.get("datos");

            // Write CSV Header
            writer.write("event_time,order_id,product_id,category_id\n");

            // Iterate over employees and write to CSV
            for (Object employeeObj : employees) {
                JSONObject employee = (JSONObject) employeeObj;
                writer.write(employee.get("event_time") + ",");
                writer.write(employee.get("order_id") + ",");
                writer.write(employee.get("product_id") + ",");
                writer.write(employee.get("category_id") + "\n");
            }

            System.out.println("El archivo JSON ha sido escrito a CSV " + outputFilePath);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
